const DBKEY='atlas_gestao_db';
const initial={
products:[
{id:'1',code:'PRD-001',name:'Produto A',category:'Acabado',stock:120,price:49.9,supplier:'Fornecedor Alpha',min:20},
{id:'2',code:'PRD-002',name:'Produto B',category:'Matéria-prima',stock:8,price:89.9,supplier:'Fornecedor Beta',min:15}],
finances:[
{id:'1',date:'2026-08-01',type:'Receita',category:'Vendas',value:12500,description:'Vendas do mês'},
{id:'2',date:'2026-08-03',type:'Despesa',category:'Operacional',value:4300,description:'Despesas operacionais'}],
sales:[],employees:[{id:'1',name:'Administrador',role:'Gestor',sector:'Administração',phone:'',email:'admin@atlasgestao.com',status:'Ativo'}],
inspections:[],audits:[],documents:[],messages:[]};
function getDB(){let d=localStorage.getItem(DBKEY);if(!d){localStorage.setItem(DBKEY,JSON.stringify(initial));return structuredClone(initial)}return JSON.parse(d)}
function saveDB(d){localStorage.setItem(DBKEY,JSON.stringify(d))}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2)}
